This folder contains the best combination obtained by our analysis :
Architecture : Baseline --> trained_model_1.6_1_weights.h5
Reward Function: Waste Time & Resources Exploitation combination --> Combination 2

To test out other parameters, you can use:
the weights.h5 (to change architecture) 
or scheduler (to change the reward function), 
or agent1.6.2_ ( to change scenarios).
from their respective folders and replace them in this folder. 