import numpy as np
import random
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from enum import Enum

class SafetyStatus(Enum):
    SAFE = 0
    UNSAFE = 1

class TechnicianFeedback(Enum):
    OK = 0
    PROBLEM = 1
    CRITICAL = 2

@dataclass
class SystemState:
    """Représentation d'un état du système"""
    time_elapsed: float  # Temps écoulé sur la tâche (en heures)
    active_equipment: int  # Nombre d'équipements actifs
    task_completion: float  # Pourcentage de tâche accomplie (0-100)
    safety_status: SafetyStatus  # Statut de sécurité
    technician_feedback: TechnicianFeedback  # Feedback du technicien
    resource_availability: float  # Disponibilité des ressources (0-1)
    maintenance_priority: int  # Priorité de maintenance (1-5)
    
    def to_vector(self) -> np.ndarray:
        """Convertit l'état en vecteur numpy pour le RL"""
        return np.array([
            self.time_elapsed,
            self.active_equipment,
            self.task_completion / 100.0,  # Normaliser 0-1
            self.safety_status.value,
            self.technician_feedback.value,
            self.resource_availability,
            self.maintenance_priority / 5.0  # Normaliser 0-1
        ], dtype=np.float32)

class StateGenerator:
    """Générateur d'états simulés pour l'environnement RL"""
    
    def __init__(self, 
                 max_equipment: int = 10,
                 max_time: float = 8.0,  # 8 heures max
                 noise_level: float = 0.1):
        self.max_equipment = max_equipment
        self.max_time = max_time
        self.noise_level = noise_level
        self.current_state = None
        self.scenario_params = self._init_scenario_params()
        
    def _init_scenario_params(self) -> Dict:
        """Initialise les paramètres des différents scénarios"""
        return {
            'scenario_1': {  # Scénario normal
                'equipment_range': (3, 7),
                'completion_rate': 0.15,  # 15% par étape
                'safety_risk': 0.05,
                'feedback_quality': 0.9
            },
            'scenario_2': {  # Scénario avec contraintes
                'equipment_range': (1, 4),
                'completion_rate': 0.08,
                'safety_risk': 0.15,
                'feedback_quality': 0.7
            },
            'scenario_3': {  # Scénario critique
                'equipment_range': (5, 10),
                'completion_rate': 0.05,
                'safety_risk': 0.25,
                'feedback_quality': 0.5
            }
        }
    
    def generate_initial_state(self, scenario: str = 'scenario_1') -> SystemState:
        """Génère un état initial selon le scénario"""
        params = self.scenario_params.get(scenario, self.scenario_params['scenario_1'])
        
        # Générer les valeurs initiales
        equipment_range = params['equipment_range']
        active_equipment = random.randint(equipment_range[0], equipment_range[1])
        
        initial_state = SystemState(
            time_elapsed=0.0,
            active_equipment=active_equipment,
            task_completion=0.0,
            safety_status=SafetyStatus.SAFE,
            technician_feedback=TechnicianFeedback.OK,
            resource_availability=random.uniform(0.7, 1.0),
            maintenance_priority=random.randint(1, 3)
        )
        
        self.current_state = initial_state
        return initial_state
    
    def simulate_state_transition(self, 
                                  current_state: SystemState, 
                                  action: int,
                                  scenario: str = 'scenario_1') -> Tuple[SystemState, Dict]:
        """Simule la transition d'état basée sur l'action"""
        params = self.scenario_params.get(scenario, self.scenario_params['scenario_1'])
        
        # Copier l'état actuel
        new_state = SystemState(
            time_elapsed=current_state.time_elapsed,
            active_equipment=current_state.active_equipment,
            task_completion=current_state.task_completion,
            safety_status=current_state.safety_status,
            technician_feedback=current_state.technician_feedback,
            resource_availability=current_state.resource_availability,
            maintenance_priority=current_state.maintenance_priority
        )
        
        # Simuler l'effet de l'action
        action_effects = self._simulate_action_effects(action, params)
        
        # Mettre à jour le temps
        new_state.time_elapsed += action_effects['time_delta']
        
        # Mettre à jour la completion
        completion_gain = action_effects['completion_gain']
        new_state.task_completion = min(100.0, 
                                       current_state.task_completion + completion_gain)
        
        # Mettre à jour l'équipement actif
        equipment_change = action_effects['equipment_change']
        new_state.active_equipment = max(0, 
                                        min(self.max_equipment,
                                            current_state.active_equipment + equipment_change))
        
        # Simuler les risques de sécurité
        safety_risk = params['safety_risk'] * action_effects['risk_multiplier']
        if random.random() < safety_risk:
            new_state.safety_status = SafetyStatus.UNSAFE
        else:
            new_state.safety_status = SafetyStatus.SAFE
            
        # Simuler le feedback du technicien
        new_state.technician_feedback = self._simulate_technician_feedback(
            new_state, params['feedback_quality']
        )
        
        # Mise à jour des ressources
        resource_consumption = action_effects['resource_consumption']
        new_state.resource_availability = max(0.0, 
            current_state.resource_availability - resource_consumption)
        
        # Ajuster la priorité de maintenance
        if new_state.safety_status == SafetyStatus.UNSAFE:
            new_state.maintenance_priority = min(5, new_state.maintenance_priority + 1)
        
        # Ajouter du bruit
        new_state = self._add_noise(new_state)
        
        # Informations supplémentaires
        transition_info = {
            'action_executed': action,
            'time_delta': action_effects['time_delta'],
            'completion_gain': completion_gain,
            'safety_event': new_state.safety_status == SafetyStatus.UNSAFE,
            'resource_consumed': resource_consumption
        }
        
        self.current_state = new_state
        return new_state, transition_info
    
    def _simulate_action_effects(self, action: int, params: Dict) -> Dict:
        """Simule les effets d'une action donnée"""
        # Actions possibles:
        # 0: Continuer normalement
        # 1: Accélérer (plus de ressources)
        # 2: Ralentir (sécurité prioritaire)
        # 3: Maintenance préventive
        # 4: Ajuster équipement
        
        base_completion = params['completion_rate']
        
        if action == 0:  # Continuer normalement
            return {
                'time_delta': 0.5,
                'completion_gain': base_completion * 10,
                'equipment_change': 0,
                'risk_multiplier': 1.0,
                'resource_consumption': 0.05
            }
        elif action == 1:  # Accélérer
            return {
                'time_delta': 0.3,
                'completion_gain': base_completion * 15,
                'equipment_change': 1,
                'risk_multiplier': 1.5,
                'resource_consumption': 0.12
            }
        elif action == 2:  # Ralentir
            return {
                'time_delta': 0.8,
                'completion_gain': base_completion * 8,
                'equipment_change': 0,
                'risk_multiplier': 0.5,
                'resource_consumption': 0.03
            }
        elif action == 3:  # Maintenance préventive
            return {
                'time_delta': 0.6,
                'completion_gain': base_completion * 5,
                'equipment_change': -1,
                'risk_multiplier': 0.2,
                'resource_consumption': 0.08
            }
        elif action == 4:  # Ajuster équipement
            return {
                'time_delta': 0.4,
                'completion_gain': base_completion * 12,
                'equipment_change': random.choice([-1, 0, 1]),
                'risk_multiplier': 0.8,
                'resource_consumption': 0.06
            }
        else:
            return self._simulate_action_effects(0, params)  # Action par défaut
    
    def _simulate_technician_feedback(self, 
                                      state: SystemState, 
                                      feedback_quality: float) -> TechnicianFeedback:
        """Simule le feedback du technicien"""
        # Probabilité de feedback précis basée sur la qualité
        accurate_feedback_prob = feedback_quality
        
        # Déterminer le feedback "réel" basé sur l'état
        if state.safety_status == SafetyStatus.UNSAFE:
            true_feedback = TechnicianFeedback.CRITICAL
        elif state.task_completion < 50 and state.time_elapsed > 4:
            true_feedback = TechnicianFeedback.PROBLEM
        else:
            true_feedback = TechnicianFeedback.OK
        
        # Ajouter du bruit au feedback
        if random.random() < accurate_feedback_prob:
            return true_feedback
        else:
            # Feedback moins précis
            return random.choice(list(TechnicianFeedback))
    
    def _add_noise(self, state: SystemState) -> SystemState:
        """Ajoute du bruit aux mesures"""
        noise = np.random.normal(0, self.noise_level, 3)
        
        # Ajouter du bruit aux valeurs continues
        state.time_elapsed += noise[0] * 0.1
        state.task_completion = max(0, min(100, state.task_completion + noise[1]))
        state.resource_availability = max(0, min(1, 
            state.resource_availability + noise[2] * 0.05))
        
        return state
    
    def get_state_bounds(self) -> Tuple[np.ndarray, np.ndarray]:
        """Retourne les bornes min/max des états pour la normalisation"""
        low = np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float32)
        high = np.array([self.max_time, self.max_equipment, 1.0, 1.0, 2.0, 1.0, 1.0], 
                       dtype=np.float32)
        return low, high
    
    def is_terminal_state(self, state: SystemState) -> bool:
        """Détermine si l'état est terminal"""
        return (state.task_completion >= 100.0 or 
                state.time_elapsed >= self.max_time or
                state.resource_availability <= 0.0)
    
    def get_scenario_description(self, scenario: str) -> str:
        """Retourne la description d'un scénario"""
        descriptions = {
            'scenario_1': "Scénario normal - Conditions de travail standards",
            'scenario_2': "Scénario contraint - Ressources limitées",
            'scenario_3': "Scénario critique - Haute complexité et risques"
        }
        return descriptions.get(scenario, "Scénario inconnu")

# Exemple d'utilisation
if __name__ == "__main__":
    generator = StateGenerator()
    
    # Tester les différents scénarios
    for scenario in ['scenario_1', 'scenario_2', 'scenario_3']:
        print(f"\n=== {generator.get_scenario_description(scenario)} ===")
        
        # Générer état initial
        initial_state = generator.generate_initial_state(scenario)
        print(f"État initial: {initial_state.to_vector()}")
        
        # Simuler quelques transitions
        current_state = initial_state
        for step in range(3):
            action = random.randint(0, 4)
            new_state, info = generator.simulate_state_transition(
                current_state, action, scenario
            )
            print(f"Étape {step+1} - Action {action}: {new_state.to_vector()}")
            current_state = new_state
            
            if generator.is_terminal_state(new_state):
                print("État terminal atteint!")
                break