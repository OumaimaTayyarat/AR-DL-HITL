import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import random
from collections import deque
from typing import List, Tuple, Optional
import pickle
import os

class ReplayBuffer:
    """Buffer de mémoire pour stocker les expériences de l'agent"""
    
    def __init__(self, capacity: int = 10000):
        self.capacity = capacity
        self.buffer = deque(maxlen=capacity)
        
    def push(self, state: np.ndarray, action: int, reward: float, 
             next_state: np.ndarray, done: bool):
        """Ajoute une expérience au buffer"""
        self.buffer.append((state, action, reward, next_state, done))
    
    def sample(self, batch_size: int) -> List[Tuple]:
        """Échantillonne un batch d'expériences"""
        return random.sample(self.buffer, batch_size)
    
    def __len__(self):
        return len(self.buffer)

class DQNAgent:
    """Agent Deep Q-Network pour l'apprentissage par renforcement"""
    
    def __init__(self, 
                 state_size: int = 7,
                 action_size: int = 5,
                 learning_rate: float = 0.001,
                 gamma: float = 0.95,
                 epsilon: float = 1.0,
                 epsilon_min: float = 0.01,
                 epsilon_decay: float = 0.995,
                 memory_size: int = 10000,
                 batch_size: int = 32,
                 target_update_freq: int = 100):
        
        self.state_size = state_size
        self.action_size = action_size
        self.learning_rate = learning_rate
        self.gamma = gamma
        self.epsilon = epsilon
        self.epsilon_min = epsilon_min
        self.epsilon_decay = epsilon_decay
        self.batch_size = batch_size
        self.target_update_freq = target_update_freq
        
        # Compteurs
        self.step_count = 0
        self.episode_count = 0
        
        # Mémoire replay
        self.memory = ReplayBuffer(memory_size)
        
        # Réseaux de neurones
        self.q_network = self._build_model()
        self.target_network = self._build_model()
        
        # Synchroniser les réseaux
        self.update_target_network()
        
        # Métriques
        self.training_history = {
            'loss': [],
            'episode_reward': [],
            'episode_length': [],
            'epsilon': []
        }
    
    def _build_model(self) -> keras.Model:
        """Construit le réseau neuronal DQN"""
        model = keras.Sequential([
            layers.Input(shape=(self.state_size,)),
            layers.Dense(128, activation='relu'),
            layers.Dropout(0.2),
            layers.Dense(128, activation='relu'),
            layers.Dropout(0.2),
            layers.Dense(64, activation='relu'),
            layers.Dense(self.action_size, activation='linear')
        ])
        
        model.compile(
            optimizer=keras.optimizers.Adam(learning_rate=self.learning_rate),
            loss='mse',
            metrics=['mae']
        )
        
        return model
    
    def act(self, state: np.ndarray, training: bool = True) -> int:
        """Choisit une action selon la politique epsilon-greedy"""
        if training and np.random.random() <= self.epsilon:
            return random.randrange(self.action_size)
        
        # Reshape pour batch
        state = state.reshape(1, -1)
        q_values = self.q_network.predict(state, verbose=0)
        return np.argmax(q_values[0])
    
    def remember(self, state: np.ndarray, action: int, reward: float, 
                 next_state: np.ndarray, done: bool):
        """Stocke l'expérience dans la mémoire"""
        self.memory.push(state, action, reward, next_state, done)
    
    def replay(self) -> Optional[float]:
        """Entraîne le réseau sur un batch d'expériences"""
        if len(self.memory) < self.batch_size:
            return None
        
        # Échantillonner un batch
        batch = self.memory.sample(self.batch_size)
        
        # Préparer les données
        states = np.array([e[0] for e in batch])
        actions = np.array([e[1] for e in batch])
        rewards = np.array([e[2] for e in batch])
        next_states = np.array([e[3] for e in batch])
        dones = np.array([e[4] for e in batch])
        
        # Prédictions actuelles
        current_q_values = self.q_network.predict(states, verbose=0)
        
        # Prédictions futures avec le réseau target
        next_q_values = self.target_network.predict(next_states, verbose=0)
        
        # Mise à jour des Q-values
        for i in range(self.batch_size):
            if dones[i]:
                target_q = rewards[i]
            else:
                target_q = rewards[i] + self.gamma * np.max(next_q_values[i])
            
            current_q_values[i][actions[i]] = target_q
        
        # Entraînement
        history = self.q_network.fit(
            states, current_q_values, 
            batch_size=self.batch_size,
            epochs=1, 
            verbose=0
        )
        
        # Mise à jour d'epsilon
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay
        
        # Mise à jour du réseau target
        self.step_count += 1
        if self.step_count % self.target_update_freq == 0:
            self.update_target_network()
        
        return history.history['loss'][0]
    
    def update_target_network(self):
        """Met à jour le réseau target avec les poids du réseau principal"""
        self.target_network.set_weights(self.q_network.get_weights())
    
    def get_action_probabilities(self, state: np.ndarray) -> np.ndarray:
        """Retourne les probabilités d'action pour un état donné"""
        state = state.reshape(1, -1)
        q_values = self.q_network.predict(state, verbose=0)
        # Softmax pour obtenir des probabilités
        exp_q = np.exp(q_values[0] - np.max(q_values[0]))
        return exp_q / np.sum(exp_q)
    
    def get_q_values(self, state: np.ndarray) -> np.ndarray:
        """Retourne les Q-values pour un état donné"""
        state = state.reshape(1, -1)
        return self.q_network.predict(state, verbose=0)[0]
    
    def save_model(self, filepath: str):
        """Sauvegarde le modèle"""
        self.q_network.save(f"{filepath}_q_network.h5")
        self.target_network.save(f"{filepath}_target_network.h5")
        
        # Sauvegarder les paramètres
        params = {
            'state_size': self.state_size,
            'action_size': self.action_size,
            'learning_rate': self.learning_rate,
            'gamma': self.gamma,
            'epsilon': self.epsilon,
            'epsilon_min': self.epsilon_min,
            'epsilon_decay': self.epsilon_decay,
            'step_count': self.step_count,
            'episode_count': self.episode_count,
            'training_history': self.training_history
        }
        
        with open(f"{filepath}_params.pkl", 'wb') as f:
            pickle.dump(params, f)
    
    def load_model(self, filepath: str):
        """Charge un modèle sauvegardé"""
        if os.path.exists(f"{filepath}_q_network.h5"):
            self.q_network = keras.models.load_model(f"{filepath}_q_network.h5")
            self.target_network = keras.models.load_model(f"{filepath}_target_network.h5")
            
            # Charger les paramètres
            if os.path.exists(f"{filepath}_params.pkl"):
                with open(f"{filepath}_params.pkl", 'rb') as f:
                    params = pickle.load(f)
                
                self.epsilon = params.get('epsilon', self.epsilon)
                self.step_count = params.get('step_count', 0)
                self.episode_count = params.get('episode_count', 0)
                self.training_history = params.get('training_history', 
                                                 {'loss': [], 'episode_reward': [], 
                                                  'episode_length': [], 'epsilon': []})
            
            print(f"Modèle chargé depuis {filepath}")
            return True
        
        return False
    
    def get_training_stats(self) -> dict:
        """Retourne les statistiques d'entraînement"""
        if not self.training_history['episode_reward']:
            return {}
        
        return {
            'episodes': len(self.training_history['episode_reward']),
            'avg_reward': np.mean(self.training_history['episode_reward'][-100:]),
            'max_reward': np.max(self.training_history['episode_reward']),
            'current_epsilon': self.epsilon,
            'memory_size': len(self.memory),
            'total_steps': self.step_count
        }
    
    def add_episode_stats(self, reward: float, length: int):
        """Ajoute les statistiques d'un épisode"""
        self.training_history['episode_reward'].append(reward)
        self.training_history['episode_length'].append(length)
        self.training_history['epsilon'].append(self.epsilon)
        self.episode_count += 1
    
    def explain_action(self, state: np.ndarray, action: int) -> str:
        """Explique pourquoi une action a été choisie"""
        q_values = self.get_q_values(state)
        action_names = [
            "Continuer normalement",
            "Accélérer le processus",
            "Ralentir (sécurité)",
            "Maintenance préventive", 
            "Ajuster équipement"
        ]
        
        explanation = f"Action choisie: {action_names[action]}\n"
        explanation += f"Q-value: {q_values[action]:.3f}\n"
        explanation += "Q-values pour toutes les actions:\n"
        
        for i, (name, q_val) in enumerate(zip(action_names, q_values)):
            marker = " <-- CHOISI" if i == action else ""
            explanation += f"  {i}: {name}: {q_val:.3f}{marker}\n"
        
        return explanation

# Fonctions utilitaires pour l'entraînement
def train_dqn_agent(agent: DQNAgent, 
                   environment, 
                   episodes: int = 1000,
                   max_steps: int = 200,
                   verbose: bool = True) -> DQNAgent:
    """Entraîne l'agent DQN"""
    
    for episode in range(episodes):
        state = environment.reset()
        total_reward = 0
        step_count = 0
        
        for step in range(max_steps):
            # Choisir une action
            action = agent.act(state, training=True)
            
            # Exécuter l'action
            next_state, reward, done, info = environment.step(action)
            
            # Stocker l'expérience
            agent.remember(state, action, reward, next_state, done)
            
            # Mettre à jour l'état
            state = next_state
            total_reward += reward
            step_count += 1
            
            # Entraîner l'agent
            loss = agent.replay()
            
            if done:
                break
        
        # Enregistrer les statistiques
        agent.add_episode_stats(total_reward, step_count)
        
        # Affichage périodique
        if verbose and episode % 100 == 0:
            stats = agent.get_training_stats()
            print(f"Épisode {episode}: Récompense={total_reward:.2f}, "
                  f"Epsilon={agent.epsilon:.3f}, "
                  f"Mémoire={len(agent.memory)}")
    
    return agent

# Exemple d'utilisation
if __name__ == "__main__":
    # Créer l'agent
    agent = DQNAgent(
        state_size=7,
        action_size=5,
        learning_rate=0.001,
        gamma=0.95,
        epsilon=1.0,
        epsilon_decay=0.995
    )
    
    # Test des fonctions
    test_state = np.random.random(7)
    print("État de test:", test_state)
    
    # Tester la prédiction
    action = agent.act(test_state, training=False)
    print(f"Action prédite: {action}")
    
    # Tester l'explication
    explanation = agent.explain_action(test_state, action)
    print("\nExplication:")
    print(explanation)
    
    # Afficher les statistiques
    stats = agent.get_training_stats()
    print("\nStatistiques:", stats)