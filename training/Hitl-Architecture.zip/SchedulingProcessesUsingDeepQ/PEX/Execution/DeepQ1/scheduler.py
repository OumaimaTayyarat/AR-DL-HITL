import numpy as np
from typing import Dict, List, Tuple, Optional, Any
import matplotlib.pyplot as plt
from state_generate import StateGenerator, SystemState, SafetyStatus, TechnicianFeedback
from agent import DQNAgent
import time
import json

class RLEnvironment:
    """Environnement RL pour le système de feedback technique"""
    
    def __init__(self, 
                 scenario: str = 'scenario_1',
                 max_steps: int = 200,
                 reward_weights: Dict[str, float] = None):
        
        self.scenario = scenario
        self.max_steps = max_steps
        self.current_step = 0
        
        # Générateur d'états
        self.state_generator = StateGenerator()
        self.current_state = None
        
        # Poids des récompenses (R1, R2, R3)
        self.reward_weights = reward_weights or {
            'completion': 1.0,      # R1: Récompense de completion
            'safety': 2.0,          # R2: Récompense de sécurité
            'efficiency': 0.5,      # R3: Récompense d'efficacité
            'feedback': 0.3         # Bonus pour feedback positif
        }
        
        # Historique
        self.episode_history = []
        self.step_history = []
        
    def reset(self) -> np.ndarray:
        """Remet l'environnement à l'état initial"""
        self.current_step = 0
        self.current_state = self.state_generator.generate_initial_state(self.scenario)
        self.step_history = []
        
        return self.current_state.to_vector()
    
    def step(self, action: int) -> Tuple[np.ndarray, float, bool, Dict]:
        """Exécute une action et retourne le nouvel état, récompense, done, info"""
        
        if self.current_state is None:
            raise ValueError("Environnement non initialisé. Appelez reset() d'abord.")
        
        # Exécuter l'action
        old_state = self.current_state
        new_state, transition_info = self.state_generator.simulate_state_transition(
            self.current_state, action, self.scenario
        )
        
        # Calculer la récompense
        reward = self._calculate_reward(old_state, new_state, action, transition_info)
        
        # Vérifier si l'épisode est terminé
        done = self._is_done(new_state)
        
        # Mettre à jour l'état
        self.current_state = new_state
        self.current_step += 1
        
        # Enregistrer l'historique
        step_info = {
            'step': self.current_step,
            'action': action,
            'old_state': old_state.to_vector(),
            'new_state': new_state.to_vector(),
            'reward': reward,
            'done': done,
            'transition_info': transition_info
        }
        self.step_history.append(step_info)
        
        # Informations supplémentaires
        info = {
            'scenario': self.scenario,
            'step': self.current_step,
            'completion': new_state.task_completion,
            'safety': new_state.safety_status.name,
            'feedback': new_state.technician_feedback.name,
            'time_elapsed': new_state.time_elapsed,
            'resources': new_state.resource_availability,
            'reward_breakdown': self._get_reward_breakdown(old_state, new_state, action, transition_info)
        }
        
        return new_state.to_vector(), reward, done, info
    
    def _calculate_reward(self, old_state: SystemState, new_state: SystemState, 
                         action: int, transition_info: Dict) -> float:
        """Calcule la récompense selon les fonctions R1, R2, R3"""
        
        # R1: Récompense de completion (progression de la tâche)
        completion_progress = new_state.task_completion - old_state.task_completion
        r1 = completion_progress * self.reward_weights['completion']
        
        # R2: Récompense de sécurité
        r2 = 0.0
        if new_state.safety_status == SafetyStatus.SAFE:
            r2 = 5.0 * self.reward_weights['safety']
        else:
            r2 = -10.0 * self.reward_weights['safety']  # Pénalité pour danger
        
        # R3: Récompense d'efficacité (basée sur temps et ressources)
        time_efficiency = max(0, 1.0 - (new_state.time_elapsed / self.state_generator.max_time))
        resource_efficiency = new_state.resource_availability
        r3 = (time_efficiency + resource_efficiency) * self.reward_weights['efficiency']
        
        # Bonus pour feedback positif du technicien
        feedback_bonus = 0.0
        if new_state.technician_feedback == TechnicianFeedback.OK:
            feedback_bonus = 2.0 * self.reward_weights['feedback']
        elif new_state.technician_feedback == TechnicianFeedback.PROBLEM:
            feedback_bonus = -1.0 * self.reward_weights['feedback']
        elif new_state.technician_feedback == TechnicianFeedback.CRITICAL:
            feedback_bonus = -5.0 * self.reward_weights['feedback']
        
        # Pénalité pour actions inefficaces
        action_penalty = 0.0
        if action == 1 and new_state.safety_status == SafetyStatus.UNSAFE:
            action_penalty = -3.0  # Pénalité pour accélérer quand c'est dangereux
        
        # Bonus pour complétion de tâche
        completion_bonus = 0.0
        if new_state.task_completion >= 100.0:
            completion_bonus = 20.0
        
        total_reward = r1 + r2 + r3 + feedback_bonus + action_penalty + completion_bonus
        
        return total_reward
    
    def _get_reward_breakdown(self, old_state: SystemState, new_state: SystemState, 
                            action: int, transition_info: Dict) -> Dict:
        """Retourne le détail du calcul de récompense"""
        completion_progress = new_state.task_completion - old_state.task_completion
        r1 = completion_progress * self.reward_weights['completion']
        
        r2 = 0.0
        if new_state.safety_status == SafetyStatus.SAFE:
            r2 = 5.0 * self.reward_weights['safety']
        else:
            r2 = -10.0 * self.reward_weights['safety']
        
        time_efficiency = max(0, 1.0 - (new_state.time_elapsed / self.state_generator.max_time))
        resource_efficiency = new_state.resource_availability
        r3 = (time_efficiency + resource_efficiency) * self.reward_weights['efficiency']
        
        feedback_bonus = 0.0
        if new_state.technician_feedback == TechnicianFeedback.OK:
            feedback_bonus = 2.0 * self.reward_weights['feedback']
        elif new_state.technician_feedback == TechnicianFeedback.PROBLEM:
            feedback_bonus = -1.0 * self.reward_weights['feedback']
        elif new_state.technician_feedback == TechnicianFeedback.CRITICAL:
            feedback_bonus = -5.0 * self.reward_weights['feedback']
        
        return {
            'completion_reward': r1,
            'safety_reward': r2,
            'efficiency_reward': r3,
            'feedback_bonus': feedback_bonus,
            'total': r1 + r2 + r3 + feedback_bonus
        }
    
    def _is_done(self, state: SystemState) -> bool:
        """Détermine si l'épisode est terminé"""
        return (self.current_step >= self.max_steps or 
                self.state_generator.is_terminal_state(state))
    
    def get_action_space_size(self) -> int:
        """Retourne le nombre d'actions possibles"""
        return 5  # Actions: 0-4
    
    def get_state_space_size(self) -> int:
        """Retourne la taille de l'espace d'état"""
        return 7  # Dimensions de l'état
    
    def render(self, mode: str = 'human') -> Optional[Any]:
        """Affiche l'état actuel de l'environnement"""
        if self.current_state is None:
            print("Environnement non initialisé")
            return
        
        state = self.current_state
        print(f"\n=== État actuel (Étape {self.current_step}) ===")
        print(f"Scénario: {self.scenario}")
        print(f"Temps écoulé: {state.time_elapsed:.2f}h")
        print(f"Équipements actifs: {state.active_equipment}")
        print(f"Progression: {state.task_completion:.1f}%")
        print(f"Sécurité: {state.safety_status.name}")
        print(f"Feedback technicien: {state.technician_feedback.name}")
        print(f"Ressources disponibles: {state.resource_availability:.2f}")
        print(f"Priorité maintenance: {state.maintenance_priority}")
        
        if mode == 'detailed' and self.step_history:
            print(f"\nDernière récompense: {self.step_history[-1]['reward']:.2f}")
            print(f"Détail récompense: {self.step_history[-1].get('reward_breakdown', {})}")
    
    def get_episode_summary(self) -> Dict:
        """Retourne un résumé de l'épisode"""
        if not self.step_history:
            return {}
        
        total_reward = sum(step['reward'] for step in self.step_history)
        final_state = self.step_history[-1]['new_state']
        
        return {
            'scenario': self.scenario,
            'total_steps': len(self.step_history),
            'total_reward': total_reward,
            'final_completion': final_state[2] * 100,  # task_completion normalisé
            'final_time': final_state[0],  # time_elapsed
            'safety_violations': sum(1 for step in self.step_history 
                                   if step['new_state'][3] == 1),  # safety_status
            'average_reward': total_reward / len(self.step_history) if self.step_history else 0
        }
    
    def plot_episode_metrics(self, save_path: Optional[str] = None):
        """Affiche les graphiques des métriques de l'épisode"""
        if not self.step_history:
            print("Pas d'historique disponible")
            return
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        
        steps = [step['step'] for step in self.step_history]
        rewards = [step['reward'] for step in self.step_history]
        completions = [step['new_state'][2] * 100 for step in self.step_history]
        times = [step['new_state'][0] for step in self.step_history]
        resources = [step['new_state'][5] for step in self.step_history]
        
        # Graphique des récompenses
        axes[0, 0].plot(steps, rewards, 'b-', linewidth=2)
        axes[0, 0].set_title('Récompenses par étape')
        axes[0, 0].set_xlabel('Étape')
        axes[0, 0].set_ylabel('Récompense')
        axes[0, 0].grid(True)
        
        # Graphique de progression
        axes[0, 1].plot(steps, completions, 'g-', linewidth=2)
        axes[0, 1].set_title('Progression de la tâche')
        axes[0, 1].set_xlabel('Étape')
        axes[0, 1].set_ylabel('Completion (%)')
        axes[0, 1].grid(True)
        
        # Graphique du temps
        axes[1, 0].plot(steps, times, 'r-', linewidth=2)
        axes[1, 0].set_title('Temps écoulé')
        axes[1, 0].set_xlabel('Étape')
        axes[1, 0].set_ylabel('Temps (h)')
        axes[1, 0].grid(True)
        
        # Graphique des ressources
        axes[1, 1].plot(steps, resources, 'orange', linewidth=2)
        axes[1, 1].set_title('Ressources disponibles')
        axes[1, 1].set_xlabel('Étape')
        axes[1, 1].set_ylabel('Ressources')
        axes[1, 1].grid(True)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        
        plt.show()


class RLScheduler:
    """Planificateur principal pour l'entraînement et l'évaluation"""
    
    def __init__(self, config: Dict = None):
        self.config = config or self._get_default_config()
        self.environments = {}
        self.agents = {}
        self.training_results = {}
        
    def _get_default_config(self) -> Dict:
        """Configuration par défaut"""
        return {
            'scenarios': ['scenario_1', 'scenario_2', 'scenario_3'],
            'agent_params': {
                'learning_rate': 0.001,
                'gamma': 0.95,
                'epsilon': 1.0,
                'epsilon_decay': 0.995,
                'memory_size': 10000,
                'batch_size': 32
            },
            'training': {
                'episodes': 1000,
                'max_steps': 200,
                'evaluation_frequency': 100,
                'save_frequency': 500
            },
            'reward_weights': {
                'completion': 1.0,
                'safety': 2.0,
                'efficiency': 0.5,
                'feedback': 0.3
            }
        }
    
    def setup_scenario(self, scenario: str):
        """Configure un scénario spécifique"""
        # Créer l'environnement
        env = RLEnvironment(
            scenario=scenario,
            max_steps=self.config['training']['max_steps'],
            reward_weights=self.config['reward_weights']
        )
        
        # Créer l'agent
        agent = DQNAgent(
            state_size=env.get_state_space_size(),
            action_size=env.get_action_space_size(),
            **self.config['agent_params']
        )
        
        self.environments[scenario] = env
        self.agents[scenario] = agent
        
        return env, agent
    
    def train_scenario(self, scenario: str, verbose: bool = True) -> Dict:
        """Entraîne un agent sur un scénario spécifique"""
        if scenario not in self.environments:
            self.setup_scenario(scenario)
        
        env = self.environments[scenario]
        agent = self.agents[scenario]
        
        training_config = self.config['training']
        results = {
            'episode_rewards': [],
            'episode_lengths': [],
            'evaluation_scores': [],
            'training_time': 0
        }
        
        start_time = time.time()
        
        for episode in range(training_config['episodes']):
            state = env.reset()
            total_reward = 0
            step_count = 0
            
            for step in range(training_config['max_steps']):
                action = agent.act(state, training=True)
                next_state, reward, done, info = env.step(action)
                
                agent.remember(state, action, reward, next_state, done)
                state = next_state
                total_reward += reward
                step_count += 1
                
                loss = agent.replay()
                
                if done:
                    break
            
            # Enregistrer les résultats
            results['episode_rewards'].append(total_reward)
            results['episode_lengths'].append(step_count)
            agent.add_episode_stats(total_reward, step_count)
            
            # Évaluation périodique
            if episode % training_config['evaluation_frequency'] == 0:
                eval_score = self._evaluate_agent(agent, env, episodes=5)
                results['evaluation_scores'].append(eval_score)
                
                if verbose:
                    print(f"Episode {episode}: Reward={total_reward:.2f}, "
                          f"Eval={eval_score:.2f}, Epsilon={agent.epsilon:.3f}")
            
            # Sauvegarde périodique
            if episode % training_config['save_frequency'] == 0:
                agent.save_model(f"models/{scenario}_episode_{episode}")
        
        results['training_time'] = time.time() - start_time
        self.training_results[scenario] = results
        
        return results
    
    def _evaluate_agent(self, agent: DQNAgent, env: RLEnvironment, 
                       episodes: int = 10) -> float:
        """Évalue l'agent sur plusieurs épisodes"""
        total_rewards = []
        
        for _ in range(episodes):
            state = env.reset()
            total_reward = 0
            
            for _ in range(env.max_steps):
                action = agent.act(state, training=False)
                state, reward, done, _ = env.step(action)
                total_reward += reward
                
                if done:
                    break
            
            total_rewards.append(total_reward)
        
        return np.mean(total_rewards)
    
    def train_all_scenarios(self, verbose: bool = True) -> Dict:
        """Entraîne tous les scénarios configurés"""
        all_results = {}
        
        for scenario in self.config['scenarios']:
            print(f"\n{'='*50}")
            print(f"Entraînement du scénario: {scenario}")
            print(f"{'='*50}")
            
            results = self.train_scenario(scenario, verbose)
            all_results[scenario] = results
            
            # Sauvegarder l'agent final
            agent = self.agents[scenario]
            agent.save_model(f"models/{scenario}_final")
        
        return all_results
    
    def compare_scenarios(self, save_path: Optional[str] = None):
        """Compare les performances entre scénarios"""
        if not self.training_results:
            print("Pas de résultats d'entraînement disponibles")
            return
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        
        for scenario, results in self.training_results.items():
            episodes = range(len(results['episode_rewards']))
            
            # Récompenses par épisode
            axes[0, 0].plot(episodes, results['episode_rewards'], 
                          label=scenario, alpha=0.7)
            
            # Moyenne mobile des récompenses
            window = 50
            if len(results['episode_rewards']) >= window:
                moving_avg = np.convolve(results['episode_rewards'], 
                                       np.ones(window)/window, mode='valid')
                axes[0, 1].plot(range(window-1, len(results['episode_rewards'])), 
                              moving_avg, label=scenario, linewidth=2)
            
            # Longueur des épisodes
            axes[1, 0].plot(episodes, results['episode_lengths'], 
                          label=scenario, alpha=0.7)
            
            # Scores d'évaluation
            if results['evaluation_scores']:
                eval_episodes = range(0, len(results['episode_rewards']), 
                                    self.config['training']['evaluation_frequency'])
                eval_episodes = eval_episodes[:len(results['evaluation_scores'])]
                axes[1, 1].plot(eval_episodes, results['evaluation_scores'], 
                              label=scenario, marker='o', linewidth=2)
        
        # Configuration des graphiques
        axes[0, 0].set_title('Récompenses par épisode')
        axes[0, 0].set_xlabel('Épisode')
        axes[0, 0].set_ylabel('Récompense')
        axes[0, 0].legend()
        axes[0, 0].grid(True)
        
        axes[0, 1].set_title('Moyenne mobile des récompenses')
        axes[0, 1].set_xlabel('Épisode')
        axes[0, 1].set_ylabel('Récompense moyenne')
        axes[0, 1].legend()
        axes[0, 1].grid(True)
        
        axes[1, 0].set_title('Longueur des épisodes')
        axes[1, 0].set_xlabel('Épisode')
        axes[1, 0].set_ylabel('Nombre d\'étapes')
        axes[1, 0].legend()
        axes[1, 0].grid(True)
        
        axes[1, 1].set_title('Scores d\'évaluation')
        axes[1, 1].set_xlabel('Épisode')
        axes[1, 1].set_ylabel('Score moyen')
        axes[1, 1].legend()
        axes[1, 1].grid(True)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        
        plt.show()
    
    def demonstrate_agent(self, scenario: str, episodes: int = 3):
        """Démontre le comportement d'un agent entraîné"""
        if scenario not in self.agents:
            print(f"Agent non disponible pour {scenario}")
            return
        
        env = self.environments[scenario]
        agent = self.agents[scenario]
        
        for episode in range(episodes):
            print(f"\n{'='*40}")
            print(f"Démonstration {episode+1} - {scenario}")
            print(f"{'='*40}")
            
            state = env.reset()
            total_reward = 0
            
            for step in range(env.max_steps):
                action = agent.act(state, training=False)
                next_state, reward, done, info = env.step(action)
                
                # Afficher l'état et l'action
                print(f"\nÉtape {step+1}:")
                print(f"  Action: {action}")
                print(f"  Récompense: {reward:.2f}")
                print(f"  Completion: {info['completion']:.1f}%")
                print(f"  Sécurité: {info['safety']}")
                print(f"  Feedback: {info['feedback']}")
                
                # Explication de l'action
                explanation = agent.explain_action(state, action)
                print(f"  Explication: {explanation.split('Action choisie: ')[1].split('Q-value:')[0].strip()}")
                
                state = next_state
                total_reward += reward
                
                if done:
                    print(f"\nÉpisode terminé!")
                    break
            
            print(f"Récompense totale: {total_reward:.2f}")
            
            # Afficher le résumé
            summary = env.get_episode_summary()
            print(f"Résumé: {summary}")


# Exemple d'utilisation principale
if __name__ == "__main__":
    # Créer le planificateur
    scheduler = RLScheduler()
    
    # Test d'un scénario simple
    print("=== Test d'un scénario simple ===")
    env, agent = scheduler.setup_scenario('scenario_1')
    
    # Démonstration avant entraînement
    print("\nAgent avant entraînement:")
    scheduler.demonstrate_agent('scenario_1', episodes=1)
    
    # Entraînement court pour demo
    print("\nEntraînement court (100 épisodes)...")
    scheduler.config['training']['episodes'] = 100
    results = scheduler.train_scenario('scenario_1', verbose=True)
    
    # Démonstration après entraînement
    print("\nAgent après entraînement:")
    scheduler.demonstrate_agent('scenario_1', episodes=1)
    
    print("\n=== Fin du test ===")