#!/usr/bin/env python3
"""
Script principal pour le système RL de feedback technique
Utilise les modules: state_generate.py, agent.py, scheduler.py
"""

import os
import sys
import argparse
import json
import numpy as np
from typing import Dict, List
import matplotlib.pyplot as plt
from datetime import datetime

# Import des modules du projet
from state_generate import StateGenerator, SystemState
from agent import DQNAgent, train_dqn_agent
from scheduler import RLScheduler, RLEnvironment


def create_directories():
    """Crée les dossiers nécessaires"""
    dirs = ['models', 'logs', 'plots', 'results']
    for dir_name in dirs:
        if not os.path.exists(dir_name):
            os.makedirs(dir_name)
            print(f"Dossier créé: {dir_name}")


def load_configuration(config_path: str = None) -> Dict:
    """Charge la configuration depuis un fichier JSON ou utilise la config par défaut"""
    default_config = {
        "scenarios": ["scenario_1", "scenario_2", "scenario_3"],
        "agent_params": {
            "learning_rate": 0.001,
            "gamma": 0.95,
            "epsilon": 1.0,
            "epsilon_decay": 0.995,
            "memory_size": 10000,
            "batch_size": 32
        },
        "training": {
            "episodes": 1000,
            "max_steps": 200,
            "evaluation_frequency": 100,
            "save_frequency": 500
        },
        "reward_weights": {
            "completion": 1.0,
            "safety": 2.0,
            "efficiency": 0.5,
            "feedback": 0.3
        }
    }
    
    if config_path and os.path.exists(config_path):
        with open(config_path, 'r') as f:
            config = json.load(f)
        print(f"Configuration chargée depuis: {config_path}")
    else:
        config = default_config
        print("Configuration par défaut utilisée")
    
    return config


def run_single_scenario_demo():
    """Démonstration rapide avec un seul scénario"""
    print("=== Démonstration rapide - Scénario 1 ===")
    
    # Configuration simple
    config = load_configuration()
    config['training']['episodes'] = 200  # Réduire pour la démo
    
    # Créer le scheduler
    scheduler = RLScheduler(config)
    
    # Setup et entraînement
    env, agent = scheduler.setup_scenario('scenario_1')
    
    print("Agent avant entraînement:")
    scheduler.demonstrate_agent('scenario_1', episodes=1)
    
    print("\nEntraînement en cours...")
    results = scheduler.train_scenario('scenario_1', verbose=True)
    
    print("\nAgent après entraînement:")
    scheduler.demonstrate_agent('scenario_1', episodes=2)
    
    # Afficher les métriques
    env.plot_episode_metrics(save_path='plots/demo_metrics.png')
    
    return results


def run_full_training():
    """Entraînement complet sur tous les scénarios"""
    print("=== Entraînement complet - Tous les scénarios ===")
    
    # Charger la configuration
    config = load_configuration()
    
    # Créer le scheduler
    scheduler = RLScheduler(config)
    
    # Entraînement de tous les scénarios
    all_results = scheduler.train_all_scenarios(verbose=True)
    
    # Comparaison des résultats
    scheduler.compare_scenarios(save_path='plots/scenario_comparison.png')
    
    # Sauvegarder les résultats
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    results_file = f"results/training_results_{timestamp}.json"
    
    # Convertir les numpy arrays en listes pour JSON
    json_results = {}
    for scenario, results in all_results.items():
        json_results[scenario] = {
            'episode_rewards': [float(r) for r in results['episode_rewards']],
            'episode_lengths': [int(l) for l in results['episode_lengths']],
            'evaluation_scores': [float(s) for s in results['evaluation_scores']],
            'training_time': float(results['training_time'])
        }
    
    with open(results_file, 'w') as f:
        json.dump(json_results, f, indent=2)
    
    print(f"\nRésultats sauvegardés dans: {results_file}")
    
    # Démonstration finale
    print("\n=== Démonstrations finales ===")
    for scenario in config['scenarios']:
        print(f"\n--- {scenario} ---")
        scheduler.demonstrate_agent(scenario, episodes=1)
    
    return all_results


def run_evaluation_mode(model_path: str, scenario: str = 'scenario_1'):
    """Mode évaluation avec un modèle pré-entraîné"""
    print(f"=== Mode évaluation - {scenario} ===")
    
    # Créer l'environnement
    env = RLEnvironment(scenario=scenario)
    
    # Créer et charger l'agent
    agent = DQNAgent(
        state_size=env.get_state_space_size(),
        action_size=env.get_action_space_size()
    )
    
    if agent.load_model(model_path):
        print(f"Modèle chargé depuis: {model_path}")
    else:
        print(f"Impossible de charger le modèle: {model_path}")
        return
    
    # Évaluation
    print("\nÉvaluation de l'agent...")
    total_rewards = []
    
    for episode in range(10):
        state = env.reset()
        total_reward = 0
        
        for step in range(env.max_steps):
            action = agent.act(state, training=False)
            state, reward, done, info = env.step(action)
            total_reward += reward
            
            if done:
                break
        
        total_rewards.append(total_reward)
        print(f"Épisode {episode+1}: Récompense = {total_reward:.2f}")
    
    # Statistiques
    print(f"\nMoyenne: {np.mean(total_rewards):.2f}")
    print(f"Écart-type: {np.std(total_rewards):.2f}")
    print(f"Min: {np.min(total_rewards):.2f}")
    print(f"Max: {np.max(total_rewards):.2f}")
    
    # Démonstration détaillée
    print("\n=== Démonstration détaillée ===")
    state = env.reset()
    total_reward = 0
    
    for step in range(env.max_steps):
        action = agent.act(state, training=False)
        next_state, reward, done, info = env.step(action)
        
        print(f"\nÉtape {step+1}:")
        print(f"  Action: {action}")
        print(f"  Récompense: {reward:.2f}")
        print(f"  Info: {info}")
        print(f"  Explication: {agent.explain_action(state, action)}")
        
        state = next_state
        total_reward += reward
        
        if done:
            break
    
    print(f"\nRécompense totale: {total_reward:.2f}")


def run_hyperparameter_tuning():
    """Optimisation des hyperparamètres"""
    print("=== Optimisation des hyperparamètres ===")
    
    # Grille de recherche
    param_grid = {
        'learning_rate': [0.0001, 0.001, 0.01],
        'gamma': [0.9, 0.95, 0.99],
        'epsilon_decay': [0.990, 0.995, 0.999],
        'batch_size': [16, 32, 64]
    }
    
    base_config = load_configuration()
    base_config['training']['episodes'] = 300  # Réduire pour l'optimisation
    
    best_score = float('-inf')
    best_params = None
    results = []
    
    # Test de toutes les combinaisons (attention: peut être long!)
    import itertools
    param_combinations = list(itertools.product(*param_grid.values()))
    
    print(f"Test de {len(param_combinations)} combinaisons...")
    
    for i, params in enumerate(param_combinations):
        print(f"\nCombination {i+1}/{len(param_combinations)}")
        
        # Mise à jour des paramètres
        config = base_config.copy()
        config['agent_params'].update(dict(zip(param_grid.keys(), params)))
        
        print(f"Paramètres: {dict(zip(param_grid.keys(), params))}")
        
        # Entraînement
        scheduler = RLScheduler(config)
        scenario_results = scheduler.train_scenario('scenario_1', verbose=False)
        
        # Score basé sur la moyenne des derniers épisodes
        score = np.mean(scenario_results['episode_rewards'][-50:])
        results.append({
            'params': dict(zip(param_grid.keys(), params)),
            'score': score
        })
        
        print(f"Score: {score:.2f}")
        
        if score > best_score:
            best_score = score
            best_params = dict(zip(param_grid.keys(), params))
            print(f"Nouveau meilleur score: {best_score:.2f}")
    
    # Sauvegarder les résultats
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    results_file = f"results/hyperparameter_tuning_{timestamp}.json"
    
    with open(results_file, 'w') as f:
        json.dump({
            'best_params': best_params,
            'best_score': float(best_score),
            'all_results': results
        }, f, indent=2)
    
    print(f"\nMeilleurs paramètres: {best_params}")
    print(f"Meilleur score: {best_score:.2f}")
    print(f"Résultats sauvegardés dans: {results_file}")
    
    return best_params, best_score


def run_interactive_mode():
    """Mode interactif pour tester l'agent"""
    print("=== Mode interactif ===")
    
    # Charger la configuration
    config = load_configuration()
    
    # Créer le scheduler
    scheduler = RLScheduler(config)
    
    while True:
        print("\nOptions disponibles:")
        print("1. Entraîner un scénario")
        print("2. Tester un agent")
        print("3. Comparer les scénarios")
        print("4. Générer un rapport")
        print("5. Quitter")
        
        choice = input("\nVotre choix (1-5): ").strip()
        
        if choice == '1':
            scenario = input("Nom du scénario: ").strip()
            if scenario in config['scenarios']:
                print(f"Entraînement de {scenario}...")
                results = scheduler.train_scenario(scenario, verbose=True)
                print(f"Entraînement terminé. Score moyen: {np.mean(results['episode_rewards'][-100:]):.2f}")
            else:
                print(f"Scénario inconnu. Disponibles: {config['scenarios']}")
        
        elif choice == '2':
            scenario = input("Nom du scénario: ").strip()
            if scenario in config['scenarios']:
                episodes = int(input("Nombre d'épisodes (défaut: 1): ") or 1)
                scheduler.demonstrate_agent(scenario, episodes=episodes)
            else:
                print(f"Scénario inconnu. Disponibles: {config['scenarios']}")
        
        elif choice == '3':
            scheduler.compare_scenarios(save_path='plots/interactive_comparison.png')
            print("Comparaison sauvegardée dans plots/interactive_comparison.png")
        
        elif choice == '4':
            generate_report(scheduler)
        
        elif choice == '5':
            print("Au revoir!")
            break
        
        else:
            print("Choix invalide. Veuillez choisir entre 1 et 5.")


def generate_report(scheduler: RLScheduler):
    """Génère un rapport détaillé"""
    print("\n=== Génération du rapport ===")
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_file = f"results/report_{timestamp}.txt"
    
    with open(report_file, 'w') as f:
        f.write("RAPPORT D'ENTRAÎNEMENT RL\n")
        f.write("=" * 50 + "\n\n")
        f.write(f"Généré le: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        
        # Informations sur les scénarios
        f.write("SCÉNARIOS DISPONIBLES:\n")
        f.write("-" * 20 + "\n")
        for scenario in scheduler.config['scenarios']:
            f.write(f"- {scenario}\n")
        f.write("\n")
        
        # Configuration
        f.write("CONFIGURATION:\n")
        f.write("-" * 15 + "\n")
        f.write(json.dumps(scheduler.config, indent=2))
        f.write("\n\n")
        
        # Performances par scénario
        f.write("PERFORMANCES:\n")
        f.write("-" * 15 + "\n")
        
        for scenario in scheduler.config['scenarios']:
            if scenario in scheduler.agents:
                env = scheduler.environments[scenario]
                f.write(f"\n{scenario.upper()}:\n")
                f.write(f"  Épisodes totaux: {len(env.episode_rewards)}\n")
                if env.episode_rewards:
                    f.write(f"  Récompense moyenne: {np.mean(env.episode_rewards):.2f}\n")
                    f.write(f"  Meilleure récompense: {np.max(env.episode_rewards):.2f}\n")
                    f.write(f"  Dernière récompense: {env.episode_rewards[-1]:.2f}\n")
                else:
                    f.write("  Aucune donnée d'entraînement\n")
    
    print(f"Rapport sauvegardé dans: {report_file}")


def main():
    """Fonction principale"""
    parser = argparse.ArgumentParser(description='Système RL de feedback technique')
    parser.add_argument('--mode', choices=['demo', 'train', 'eval', 'tune', 'interactive'], 
                       default='demo', help='Mode d\'exécution')
    parser.add_argument('--config', type=str, help='Fichier de configuration JSON')
    parser.add_argument('--model', type=str, help='Chemin du modèle (pour mode eval)')
    parser.add_argument('--scenario', type=str, default='scenario_1', 
                       help='Scénario à utiliser (pour mode eval)')
    parser.add_argument('--verbose', action='store_true', help='Affichage verbeux')
    
    args = parser.parse_args()
    
    # Créer les dossiers nécessaires
    create_directories()
    
    # Exécuter selon le mode
    try:
        if args.mode == 'demo':
            results = run_single_scenario_demo()
            
        elif args.mode == 'train':
            results = run_full_training()
            
        elif args.mode == 'eval':
            if not args.model:
                print("Erreur: --model requis pour le mode eval")
                sys.exit(1)
            run_evaluation_mode(args.model, args.scenario)
            
        elif args.mode == 'tune':
            best_params, best_score = run_hyperparameter_tuning()
            
        elif args.mode == 'interactive':
            run_interactive_mode()
            
        print("\nExécution terminée avec succès!")
        
    except KeyboardInterrupt:
        print("\nInterruption utilisateur. Arrêt du programme.")
        sys.exit(0)
        
    except Exception as e:
        print(f"\nErreur lors de l'exécution: {str(e)}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()