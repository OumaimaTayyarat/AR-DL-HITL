reward : Waste Time & Production Time

---> scheduler15.py
    def calculate_reward(self):
        """calculate reward helper function"""
        if type(self.state) is str:
            return -1
        m1 = self.state['resource1']
        m2 = self.state['resource2']
        #r1, r2 = self.fetch_reward(m1), self.fetch_reward(m2)
        r1, r2 = self.fetch_reward(m1)[0], self.fetch_reward(m2)[0]
        d1, d2 = self.fetch_reward(m1)[1], self.fetch_reward(m2)[1]
        
        return max(r1,r2) - 2*max(d1,d2)

# to change the architecture, modify the agent1.6_2.py file

class Agent():
    def __init__(self, state_size, action_size,actions):
        self.weight_backup      = "trained_model_1.6_3_weight.h5"
        self.state_size         = state_size
        self.action_size        = action_size
        self.actions            = actions
        self.memory             = deque(maxlen=2000)
        self.learning_rate      = 0.001
        self.gamma              = 0.95
        self.exploration_rate   = 0.999
        self.exploration_min    = 0.05
        self.exploration_decay  = 0.999
        self.brain              = self._build_model()
        self.target_brain       = self._build_model()
        self.loss               = []
